const fetch = require("node-fetch");

exports.handler = (event, context, callback) => {
    context.callbackWaitsForEmptyEventLoop = false;
    let url;
    const RIOT_URL = '.api.riotgames.com/lol/';

    if (event.endpoint === 'summoner') {
        url = `https://${event.region}${RIOT_URL}summoner/v4/summoners/by-name/${event.summonerName}?api_key=${process.env.RIOT_API_KEY}`;
    } else if (event.endpoint === 'matchList') {
        url = `https://${event.region}${RIOT_URL}match/v4/matchlists/by-account/${event.accountId}?champion=${event.championId}&endIndex=10&queue=400&queue=420&queue=440&queue=700&api_key=${process.env.RIOT_API_KEY}`;
    } else if (event.endpoint === 'matches') {
        url = `https://${event.region}${RIOT_URL}match/v4/matches/${event.matchId}?api_key=${process.env.RIOT_API_KEY}`;
    } else if (event.endpoint === 'matchTimeline') {
        url = `https://${event.region}${RIOT_URL}match/v4/timelines/by-match/${event.matchId}?api_key=${process.env.RIOT_API_KEY}`;
    }

    fetch(url).then(res => {
        if (!res.ok) {
            throw Error(res.statusText);
        }
        return res.json();
    })
    .then(response => callback(null, response))
    .catch(error => callback(error));
};
